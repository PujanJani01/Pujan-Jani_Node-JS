const patientService = require("../services/doctor.services.js");

const getpatient = patientService.getDoctorLogic;

const postpatient = patientService.postDoctorLogic;

const putpatient = patientService.putDoctorLogic;

const patchpatient = patientService.patchDoctorLogic;

const deletepatient = patientService.deleteDoctorLogic;

module.exports = { getpatient, postpatient, putpatient, patchpatient, deletepatient };